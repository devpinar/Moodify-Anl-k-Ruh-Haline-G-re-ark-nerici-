
'use client';

import { useState } from 'react';
import MoodSelector from '@/components/MoodSelector';
import MusicRecommendations from '@/components/MusicRecommendations';
import { SpotifyTrack, getSpotifyAccessToken, searchSpotifyTracks } from '@/lib/spotify';

interface Mood {
  emoji: string;
  label: string;
  keyword: string;
  color: string;
}

export default function Home() {
  const [selectedMood, setSelectedMood] = useState<Mood | null>(null);
  const [tracks, setTracks] = useState<SpotifyTrack[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string>('');

  const handleMoodSelect = async (mood: Mood) => {
    setSelectedMood(mood);
    setIsLoading(true);
    setError('');
    setTracks([]);

    try {
      const accessToken = await getSpotifyAccessToken();
      const searchResults = await searchSpotifyTracks(mood.keyword, accessToken);
      setTracks(searchResults);
    } catch (err) {
      setError('Please add your Spotify API credentials to use this feature');
      console.error('Spotify API Error:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleBack = () => {
    setSelectedMood(null);
    setTracks([]);
    setError('');
  };

  if (selectedMood) {
    return (
      <MusicRecommendations
        mood={selectedMood}
        tracks={tracks}
        onBack={handleBack}
        isLoading={isLoading}
        error={error}
      />
    );
  }

  return (
    <MoodSelector 
      onMoodSelect={handleMoodSelect}
      isLoading={isLoading}
    />
  );
}
