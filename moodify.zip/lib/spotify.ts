
export const SPOTIFY_CLIENT_ID = '605d92c2bd2a40beae1a94c06b93dd3a';
export const SPOTIFY_CLIENT_SECRET = 'your_spotify_client_secret_here'; // Add your Client Secret here

export interface SpotifyTrack {
  id: string;
  name: string;
  artists: { name: string }[];
  album: {
    name: string;
    images: { url: string; height: number; width: number }[];
  };
  external_urls: {
    spotify: string;
  };
  preview_url?: string;
}

export interface SpotifySearchResponse {
  tracks: {
    items: SpotifyTrack[];
  };
}

export async function getSpotifyAccessToken(): Promise<string> {
  // Check if credentials are properly configured
  if (SPOTIFY_CLIENT_SECRET === 'your_spotify_client_secret_here') {
    // Return mock data for demo purposes when credentials are not configured
    console.warn('Using demo mode - please add your Spotify Client Secret for real data');
    return 'demo_token';
  }

  const credentials = btoa(`${SPOTIFY_CLIENT_ID}:${SPOTIFY_CLIENT_SECRET}`);

  const response = await fetch('https://accounts.spotify.com/api/token', {
    method: 'POST',
    headers: {
      'Authorization': `Basic ${credentials}`,
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: 'grant_type=client_credentials',
  });

  if (!response.ok) {
    const errorData = await response.text();
    console.error('Spotify API Error:', errorData);
    throw new Error(`Failed to get Spotify access token: ${response.status}`);
  }

  const data = await response.json();
  return data.access_token;
}

export async function searchSpotifyTracks(mood: string, accessToken: string): Promise<SpotifyTrack[]> {
  // Return demo data when using demo token
  if (accessToken === 'demo_token') {
    return generateDemoTracks(mood);
  }

  const response = await fetch(
    `https://api.spotify.com/v1/search?q=${encodeURIComponent(mood)}&type=track&limit=10`,
    {
      headers: {
        'Authorization': `Bearer ${accessToken}`,
      },
    }
  );

  if (!response.ok) {
    throw new Error('Failed to search Spotify tracks');
  }

  const data: SpotifySearchResponse = await response.json();
  return data.tracks.items;
}

// Demo data generator for when credentials are not configured
function generateDemoTracks(mood: string): SpotifyTrack[] {
  const demoTracks: Record<string, SpotifyTrack[]> = {
    happy: [
      {
        id: 'demo1',
        name: 'Sunny Days',
        artists: [{ name: 'The Brightside' }],
        album: {
          name: 'Golden Hour',
          images: [{ url: 'https://readdy.ai/api/search-image?query=minimalist%20album%20cover%2C%20clean%20white%20background%2C%20golden%20sun%20icon%2C%20modern%20typography%2C%20simple%20geometric%20design&width=300&height=300&seq=happy1&orientation=squarish', height: 300, width: 300 }]
        },
        external_urls: { spotify: 'https://spotify.com' },
        preview_url: ''
      },
      {
        id: 'demo2',
        name: 'Good Vibes Only',
        artists: [{ name: 'Positive Energy' }],
        album: {
          name: 'Uplifting',
          images: [{ url: 'https://readdy.ai/api/search-image?query=clean%20album%20cover%2C%20white%20background%2C%20simple%20smile%20icon%2C%20minimal%20design%2C%20modern%20aesthetic&width=300&height=300&seq=happy2&orientation=squarish', height: 300, width: 300 }]
        },
        external_urls: { spotify: 'https://spotify.com' },
        preview_url: ''
      },
      {
        id: 'demo3',
        name: 'Feel Good Time',
        artists: [{ name: 'Happy Beats' }],
        album: {
          name: 'Joy',
          images: [{ url: 'https://readdy.ai/api/search-image?query=minimal%20album%20artwork%2C%20white%20background%2C%20single%20yellow%20circle%2C%20clean%20typography%2C%20modern%20design&width=300&height=300&seq=happy3&orientation=squarish', height: 300, width: 300 }]
        },
        external_urls: { spotify: 'https://spotify.com' },
        preview_url: ''
      },
      {
        id: 'demo4',
        name: 'Dance With Me',
        artists: [{ name: 'Upbeat Crew' }],
        album: {
          name: 'Move',
          images: [{ url: 'https://readdy.ai/api/search-image?query=simple%20album%20cover%2C%20clean%20white%20background%2C%20abstract%20orange%20shape%2C%20minimalist%20style%2C%20contemporary%20design&width=300&height=300&seq=happy4&orientation=squarish', height: 300, width: 300 }]
        },
        external_urls: { spotify: 'https://spotify.com' },
        preview_url: ''
      },
      {
        id: 'demo5',
        name: 'Celebrate Life',
        artists: [{ name: 'Joy Makers' }],
        album: {
          name: 'Celebration',
          images: [{ url: 'https://readdy.ai/api/search-image?query=minimalist%20cover%20art%2C%20white%20background%2C%20simple%20confetti%20pattern%2C%20clean%20design%2C%20modern%20aesthetic&width=300&height=300&seq=happy5&orientation=squarish', height: 300, width: 300 }]
        },
        external_urls: { spotify: 'https://spotify.com' },
        preview_url: ''
      },
      {
        id: 'demo6',
        name: 'Morning Coffee',
        artists: [{ name: 'Daily Sunshine' }],
        album: {
          name: 'Fresh Start',
          images: [{ url: 'https://readdy.ai/api/search-image?query=clean%20album%20design%2C%20white%20background%2C%20simple%20coffee%20cup%20silhouette%2C%20minimal%20typography%2C%20modern%20style&width=300&height=300&seq=happy6&orientation=squarish', height: 300, width: 300 }]
        },
        external_urls: { spotify: 'https://spotify.com' },
        preview_url: ''
      },
      {
        id: 'demo7',
        name: 'Weekend Mood',
        artists: [{ name: 'Chill Happy' }],
        album: {
          name: 'Relaxed Joy',
          images: [{ url: 'https://readdy.ai/api/search-image?query=minimalist%20album%20art%2C%20clean%20white%20background%2C%20simple%20geometric%20sun%2C%20modern%20clean%20design&width=300&height=300&seq=happy7&orientation=squarish', height: 300, width: 300 }]
        },
        external_urls: { spotify: 'https://spotify.com' },
        preview_url: ''
      },
      {
        id: 'demo8',
        name: 'Smile Again',
        artists: [{ name: 'Positive Waves' }],
        album: {
          name: 'Happiness',
          images: [{ url: 'https://readdy.ai/api/search-image?query=simple%20album%20cover%2C%20white%20background%2C%20minimalist%20heart%20shape%2C%20clean%20typography%2C%20contemporary%20style&width=300&height=300&seq=happy8&orientation=squarish', height: 300, width: 300 }]
        },
        external_urls: { spotify: 'https://spotify.com' },
        preview_url: ''
      }
    ],
    sad: [
      {
        id: 'demo9',
        name: 'Rainy Window',
        artists: [{ name: 'Melancholy Soul' }],
        album: {
          name: 'Quiet Moments',
          images: [{ url: 'https://readdy.ai/api/search-image?query=minimal%20album%20cover%2C%20clean%20white%20background%2C%20single%20grey%20raindrop%2C%20modern%20typography%2C%20simple%20design&width=300&height=300&seq=sad1&orientation=squarish', height: 300, width: 300 }]
        },
        external_urls: { spotify: 'https://spotify.com' },
        preview_url: ''
      },
      {
        id: 'demo10',
        name: 'Empty Streets',
        artists: [{ name: 'Solitude' }],
        album: {
          name: 'Alone',
          images: [{ url: 'https://readdy.ai/api/search-image?query=minimalist%20cover%20art%2C%20white%20background%2C%20simple%20line%20drawing%20of%20empty%20path%2C%20clean%20aesthetic&width=300&height=300&seq=sad2&orientation=squarish', height: 300, width: 300 }]
        },
        external_urls: { spotify: 'https://spotify.com' },
        preview_url: ''
      },
      {
        id: 'demo11',
        name: 'Midnight Thoughts',
        artists: [{ name: 'Deep Feelings' }],
        album: {
          name: 'Reflection',
          images: [{ url: 'https://readdy.ai/api/search-image?query=clean%20album%20design%2C%20white%20background%2C%20simple%20moon%20crescent%2C%20minimal%20style%2C%20modern%20typography&width=300&height=300&seq=sad3&orientation=squarish', height: 300, width: 300 }]
        },
        external_urls: { spotify: 'https://spotify.com' },
        preview_url: ''
      },
      {
        id: 'demo12',
        name: 'Teardrops',
        artists: [{ name: 'Emotional Journey' }],
        album: {
          name: 'Feelings',
          images: [{ url: 'https://readdy.ai/api/search-image?query=minimalist%20album%20art%2C%20clean%20white%20background%2C%20single%20blue%20dot%2C%20contemporary%20design%2C%20simple&width=300&height=300&seq=sad4&orientation=squarish', height: 300, width: 300 }]
        },
        external_urls: { spotify: 'https://spotify.com' },
        preview_url: ''
      },
      {
        id: 'demo13',
        name: 'Lost in Time',
        artists: [{ name: 'Nostalgic Sounds' }],
        album: {
          name: 'Memory Lane',
          images: [{ url: 'https://readdy.ai/api/search-image?query=simple%20cover%20design%2C%20white%20background%2C%20minimalist%20clock%20outline%2C%20clean%20typography%2C%20modern%20style&width=300&height=300&seq=sad5&orientation=squarish', height: 300, width: 300 }]
        },
        external_urls: { spotify: 'https://spotify.com' },
        preview_url: ''
      },
      {
        id: 'demo14',
        name: 'Silent Storm',
        artists: [{ name: 'Inner Peace' }],
        album: {
          name: 'Calm After',
          images: [{ url: 'https://readdy.ai/api/search-image?query=minimal%20album%20artwork%2C%20clean%20white%20background%2C%20simple%20grey%20cloud%2C%20modern%20aesthetic%2C%20understated%20design&width=300&height=300&seq=sad6&orientation=squarish', height: 300, width: 300 }]
        },
        external_urls: { spotify: 'https://spotify.com' },
        preview_url: ''
      },
      {
        id: 'demo15',
        name: 'Faded Memories',
        artists: [{ name: 'Past Echoes' }],
        album: {
          name: 'Yesterday',
          images: [{ url: 'https://readdy.ai/api/search-image?query=clean%20album%20cover%2C%20white%20background%2C%20simple%20faded%20photograph%20icon%2C%20minimalist%20design%2C%20subtle&width=300&height=300&seq=sad7&orientation=squarish', height: 300, width: 300 }]
        },
        external_urls: { spotify: 'https://spotify.com' },
        preview_url: ''
      },
      {
        id: 'demo16',
        name: 'Whispered Goodbyes',
        artists: [{ name: 'Soft Sorrow' }],
        album: {
          name: 'Farewell',
          images: [{ url: 'https://readdy.ai/api/search-image?query=minimalist%20cover%20art%2C%20clean%20white%20background%2C%20simple%20feather%20outline%2C%20contemporary%20typography%2C%20gentle%20design&width=300&height=300&seq=sad8&orientation=squarish', height: 300, width: 300 }]
        },
        external_urls: { spotify: 'https://spotify.com' },
        preview_url: ''
      }
    ],
    angry: [
      {
        id: 'demo17',
        name: 'Breaking Point',
        artists: [{ name: 'Fury Express' }],
        album: {
          name: 'Unleashed',
          images: [{ url: 'https://readdy.ai/api/search-image?query=minimal%20album%20cover%2C%20clean%20white%20background%2C%20simple%20red%20geometric%20shape%2C%20modern%20typography%2C%20bold%20design&width=300&height=300&seq=angry1&orientation=squarish', height: 300, width: 300 }]
        },
        external_urls: { spotify: 'https://spotify.com' },
        preview_url: ''
      },
      {
        id: 'demo18',
        name: 'Fire Inside',
        artists: [{ name: 'Rage Machine' }],
        album: {
          name: 'Intensity',
          images: [{ url: 'https://readdy.ai/api/search-image?query=clean%20album%20design%2C%20white%20background%2C%20simple%20flame%20icon%20outline%2C%20minimalist%20style%2C%20contemporary&width=300&height=300&seq=angry2&orientation=squarish', height: 300, width: 300 }]
        },
        external_urls: { spotify: 'https://spotify.com' },
        preview_url: ''
      },
      {
        id: 'demo19',
        name: 'No More Lies',
        artists: [{ name: 'Truth Seekers' }],
        album: {
          name: 'Raw Truth',
          images: [{ url: 'https://readdy.ai/api/search-image?query=minimalist%20album%20art%2C%20clean%20white%20background%2C%20simple%20broken%20chain%2C%20modern%20design%2C%20powerful&width=300&height=300&seq=angry3&orientation=squarish', height: 300, width: 300 }]
        },
        external_urls: { spotify: 'https://spotify.com' },
        preview_url: ''
      },
      {
        id: 'demo20',
        name: 'Storm Rising',
        artists: [{ name: 'Thunder Force' }],
        album: {
          name: 'Electric',
          images: [{ url: 'https://readdy.ai/api/search-image?query=simple%20cover%20art%2C%20white%20background%2C%20minimalist%20lightning%20bolt%2C%20clean%20typography%2C%20bold%20aesthetic&width=300&height=300&seq=angry4&orientation=squarish', height: 300, width: 300 }]
        },
        external_urls: { spotify: 'https://spotify.com' },
        preview_url: ''
      },
      {
        id: 'demo21',
        name: 'Fight Back',
        artists: [{ name: 'Rebel Spirit' }],
        album: {
          name: 'Resistance',
          images: [{ url: 'https://readdy.ai/api/search-image?query=minimal%20album%20cover%2C%20clean%20white%20background%2C%20simple%20fist%20outline%2C%20modern%20design%2C%20strong&width=300&height=300&seq=angry5&orientation=squarish', height: 300, width: 300 }]
        },
        external_urls: { spotify: 'https://spotify.com' },
        preview_url: ''
      },
      {
        id: 'demo22',
        name: 'Scream It Out',
        artists: [{ name: 'Vocal Rage' }],
        album: {
          name: 'Release',
          images: [{ url: 'https://readdy.ai/api/search-image?query=clean%20album%20design%2C%20white%20background%2C%20simple%20sound%20wave%20graphic%2C%20minimalist%20style%2C%20contemporary&width=300&height=300&seq=angry6&orientation=squarish', height: 300, width: 300 }]
        },
        external_urls: { spotify: 'https://spotify.com' },
        preview_url: ''
      },
      {
        id: 'demo23',
        name: 'Blood Boiling',
        artists: [{ name: 'Hot Temper' }],
        album: {
          name: 'Heat',
          images: [{ url: 'https://readdy.ai/api/search-image?query=minimalist%20cover%20art%2C%20clean%20white%20background%2C%20simple%20red%20circle%2C%20modern%20typography%2C%20intense&width=300&height=300&seq=angry7&orientation=squarish', height: 300, width: 300 }]
        },
        external_urls: { spotify: 'https://spotify.com' },
        preview_url: ''
      },
      {
        id: 'demo24',
        name: 'Enough is Enough',
        artists: [{ name: 'Final Stand' }],
        album: {
          name: 'Limit',
          images: [{ url: 'https://readdy.ai/api/search-image?query=simple%20album%20cover%2C%20white%20background%2C%20minimalist%20stop%20sign%20shape%2C%20clean%20design%2C%20powerful%20message&width=300&height=300&seq=angry8&orientation=squarish', height: 300, width: 300 }]
        },
        external_urls: { spotify: 'https://spotify.com' },
        preview_url: ''
      }
    ],
    tired: [
      {
        id: 'demo25',
        name: 'Heavy Eyelids',
        artists: [{ name: 'Drowsy Dreams' }],
        album: {
          name: 'Sleepy Time',
          images: [{ url: 'https://readdy.ai/api/search-image?query=minimal%20album%20cover%2C%20clean%20white%20background%2C%20simple%20closed%20eye%20icon%2C%20modern%20typography%2C%20peaceful&width=300&height=300&seq=tired1&orientation=squarish', height: 300, width: 300 }]
        },
        external_urls: { spotify: 'https://spotify.com' },
        preview_url: ''
      },
      {
        id: 'demo26',
        name: 'Pillow Talk',
        artists: [{ name: 'Soft Whispers' }],
        album: {
          name: 'Bedtime',
          images: [{ url: 'https://readdy.ai/api/search-image?query=clean%20album%20design%2C%20white%20background%2C%20simple%20pillow%20outline%2C%20minimalist%20style%2C%20cozy%20aesthetic&width=300&height=300&seq=tired2&orientation=squarish', height: 300, width: 300 }]
        },
        external_urls: { spotify: 'https://spotify.com' },
        preview_url: ''
      },
      {
        id: 'demo27',
        name: 'Midnight Lullaby',
        artists: [{ name: 'Sleep Sounds' }],
        album: {
          name: 'Night Rest',
          images: [{ url: 'https://readdy.ai/api/search-image?query=minimalist%20album%20art%2C%20clean%20white%20background%2C%20simple%20star%20outline%2C%20contemporary%20design%2C%20gentle&width=300&height=300&seq=tired3&orientation=squarish', height: 300, width: 300 }]
        },
        external_urls: { spotify: 'https://spotify.com' },
        preview_url: ''
      },
      {
        id: 'demo28',
        name: 'Yawning Moon',
        artists: [{ name: 'Sleepy Hollow' }],
        album: {
          name: 'Dreamland',
          images: [{ url: 'https://readdy.ai/api/search-image?query=simple%20cover%20art%2C%20white%20background%2C%20minimalist%20crescent%20moon%2C%20clean%20typography%2C%20dreamy&width=300&height=300&seq=tired4&orientation=squarish', height: 300, width: 300 }]
        },
        external_urls: { spotify: 'https://spotify.com' },
        preview_url: ''
      },
      {
        id: 'demo29',
        name: 'Counting Sheep',
        artists: [{ name: 'Dream Weavers' }],
        album: {
          name: 'Sleep Cycle',
          images: [{ url: 'https://readdy.ai/api/search-image?query=minimal%20album%20cover%2C%20clean%20white%20background%2C%20simple%20sheep%20silhouette%2C%20modern%20design%2C%20peaceful&width=300&height=300&seq=tired5&orientation=squarish', height: 300, width: 300 }]
        },
        external_urls: { spotify: 'https://spotify.com' },
        preview_url: ''
      },
      {
        id: 'demo30',
        name: 'Blanket Fort',
        artists: [{ name: 'Cozy Vibes' }],
        album: {
          name: 'Comfort',
          images: [{ url: 'https://readdy.ai/api/search-image?query=clean%20album%20design%2C%20white%20background%2C%20simple%20blanket%20outline%2C%20minimalist%20style%2C%20warm%20feeling&width=300&height=300&seq=tired6&orientation=squarish', height: 300, width: 300 }]
        },
        external_urls: { spotify: 'https://spotify.com' },
        preview_url: ''
      },
      {
        id: 'demo31',
        name: 'Sleepy Clouds',
        artists: [{ name: 'Sky Dreams' }],
        album: {
          name: 'Floating',
          images: [{ url: 'https://readdy.ai/api/search-image?query=minimalist%20cover%20art%2C%20clean%20white%20background%2C%20simple%20cloud%20shape%2C%20contemporary%20typography%2C%20soft&width=300&height=300&seq=tired7&orientation=squarish', height: 300, width: 300 }]
        },
        external_urls: { spotify: 'https://spotify.com' },
        preview_url: ''
      },
      {
        id: 'demo32',
        name: 'Rest Mode',
        artists: [{ name: 'Power Down' }],
        album: {
          name: 'Shutdown',
          images: [{ url: 'https://readdy.ai/api/search-image?query=simple%20album%20cover%2C%20white%20background%2C%20minimalist%20power%20button%20icon%2C%20clean%20design%2C%20tech%20aesthetic&width=300&height=300&seq=tired8&orientation=squarish', height: 300, width: 300 }]
        },
        external_urls: { spotify: 'https://spotify.com' },
        preview_url: ''
      }
    ],
    relaxed: [
      {
        id: 'demo33',
        name: 'Ocean Breeze',
        artists: [{ name: 'Calm Waters' }],
        album: {
          name: 'Serenity',
          images: [{ url: 'https://readdy.ai/api/search-image?query=minimal%20album%20cover%2C%20clean%20white%20background%2C%20simple%20wave%20line%2C%20modern%20typography%2C%20peaceful%20design&width=300&height=300&seq=relaxed1&orientation=squarish', height: 300, width: 300 }]
        },
        external_urls: { spotify: 'https://spotify.com' },
        preview_url: ''
      },
      {
        id: 'demo34',
        name: 'Zen Garden',
        artists: [{ name: 'Mindful Moments' }],
        album: {
          name: 'Balance',
          images: [{ url: 'https://readdy.ai/api/search-image?query=clean%20album%20design%2C%20white%20background%2C%20simple%20zen%20stone%20stack%2C%20minimalist%20style%2C%20tranquil&width=300&height=300&seq=relaxed2&orientation=squarish', height: 300, width: 300 }]
        },
        external_urls: { spotify: 'https://spotify.com' },
        preview_url: ''
      },
      {
        id: 'demo35',
        name: 'Deep Breath',
        artists: [{ name: 'Inner Peace' }],
        album: {
          name: 'Meditation',
          images: [{ url: 'https://readdy.ai/api/search-image?query=minimalist%20album%20art%2C%20clean%20white%20background%2C%20simple%20lotus%20outline%2C%20contemporary%20design%2C%20spiritual&width=300&height=300&seq=relaxed3&orientation=squarish', height: 300, width: 300 }]
        },
        external_urls: { spotify: 'https://spotify.com' },
        preview_url: ''
      },
      {
        id: 'demo36',
        name: 'Floating Thoughts',
        artists: [{ name: 'Mental Clarity' }],
        album: {
          name: 'Clear Mind',
          images: [{ url: 'https://readdy.ai/api/search-image?query=simple%20cover%20art%2C%20white%20background%2C%20minimalist%20bubble%20outline%2C%20clean%20typography%2C%20light%20aesthetic&width=300&height=300&seq=relaxed4&orientation=squarish', height: 300, width: 300 }]
        },
        external_urls: { spotify: 'https://spotify.com' },
        preview_url: ''
      },
      {
        id: 'demo37',
        name: 'Sunday Morning',
        artists: [{ name: 'Lazy Days' }],
        album: {
          name: 'Weekend',
          images: [{ url: 'https://readdy.ai/api/search-image?query=minimal%20album%20cover%2C%20clean%20white%20background%2C%20simple%20coffee%20steam%2C%20modern%20design%2C%20relaxed%20mood&width=300&height=300&seq=relaxed5&orientation=squarish', height: 300, width: 300 }]
        },
        external_urls: { spotify: 'https://spotify.com' },
        preview_url: ''
      },
      {
        id: 'demo38',
        name: 'Gentle Rain',
        artists: [{ name: 'Nature Sounds' }],
        album: {
          name: 'Natural',
          images: [{ url: 'https://readdy.ai/api/search-image?query=clean%20album%20design%2C%20white%20background%2C%20simple%20raindrop%20pattern%2C%20minimalist%20style%2C%20soothing&width=300&height=300&seq=relaxed6&orientation=squarish', height: 300, width: 300 }]
        },
        external_urls: { spotify: 'https://spotify.com' },
        preview_url: ''
      },
      {
        id: 'demo39',
        name: 'Soft Light',
        artists: [{ name: 'Ambient Flow' }],
        album: {
          name: 'Glow',
          images: [{ url: 'https://readdy.ai/api/search-image?query=minimalist%20cover%20art%2C%20clean%20white%20background%2C%20simple%20gradient%20circle%2C%20contemporary%20typography%2C%20gentle&width=300&height=300&seq=relaxed7&orientation=squarish', height: 300, width: 300 }]
        },
        external_urls: { spotify: 'https://spotify.com' },
        preview_url: ''
      },
      {
        id: 'demo40',
        name: 'Peaceful Mind',
        artists: [{ name: 'Calm State' }],
        album: {
          name: 'Tranquil',
          images: [{ url: 'https://readdy.ai/api/search-image?query=simple%20album%20cover%2C%20white%20background%2C%20minimalist%20leaf%20outline%2C%20clean%20design%2C%20organic%20feel&width=300&height=300&seq=relaxed8&orientation=squarish', height: 300, width: 300 }]
        },
        external_urls: { spotify: 'https://spotify.com' },
        preview_url: ''
      }
    ],
    energetic: [
      {
        id: 'demo41',
        name: 'Power Surge',
        artists: [{ name: 'High Voltage' }],
        album: {
          name: 'Electric',
          images: [{ url: 'https://readdy.ai/api/search-image?query=minimal%20album%20cover%2C%20clean%20white%20background%2C%20simple%20lightning%20bolt%20icon%2C%20modern%20typography%2C%20dynamic&width=300&height=300&seq=energetic1&orientation=squarish', height: 300, width: 300 }]
        },
        external_urls: { spotify: 'https://spotify.com' },
        preview_url: ''
      },
      {
        id: 'demo42',
        name: 'Full Throttle',
        artists: [{ name: 'Speed Demons' }],
        album: {
          name: 'Maximum',
          images: [{ url: 'https://readdy.ai/api/search-image?query=clean%20album%20design%2C%20white%20background%2C%20simple%20arrow%20pointing%20up%2C%20minimalist%20style%2C%20powerful&width=300&height=300&seq=energetic2&orientation=squarish', height: 300, width: 300 }]
        },
        external_urls: { spotify: 'https://spotify.com' },
        preview_url: ''
      },
      {
        id: 'demo43',
        name: 'Adrenaline Rush',
        artists: [{ name: 'Pulse Racing' }],
        album: {
          name: 'Heart Beat',
          images: [{ url: 'https://readdy.ai/api/search-image?query=minimalist%20album%20art%2C%20clean%20white%20background%2C%20simple%20heartbeat%20line%2C%20contemporary%20design%2C%20energetic&width=300&height=300&seq=energetic3&orientation=squarish', height: 300, width: 300 }]
        },
        external_urls: { spotify: 'https://spotify.com' },
        preview_url: ''
      },
      {
        id: 'demo44',
        name: 'Rocket Fuel',
        artists: [{ name: 'Launch Pad' }],
        album: {
          name: 'Ignition',
          images: [{ url: 'https://readdy.ai/api/search-image?query=simple%20cover%20art%2C%20white%20background%2C%20minimalist%20rocket%20outline%2C%20clean%20typography%2C%20space%20theme&width=300&height=300&seq=energetic4&orientation=squarish', height: 300, width: 300 }]
        },
        external_urls: { spotify: 'https://spotify.com' },
        preview_url: ''
      },
      {
        id: 'demo45',
        name: 'Workout Mode',
        artists: [{ name: 'Gym Warriors' }],
        album: {
          name: 'Strength',
          images: [{ url: 'https://readdy.ai/api/search-image?query=minimal%20album%20cover%2C%20clean%20white%20background%2C%20simple%20dumbbell%20icon%2C%20modern%20design%2C%20fitness%20theme&width=300&height=300&seq=energetic5&orientation=squarish', height: 300, width: 300 }]
        },
        external_urls: { spotify: 'https://spotify.com' },
        preview_url: ''
      },
      {
        id: 'demo46',
        name: 'Victory Dance',
        artists: [{ name: 'Champion Spirit' }],
        album: {
          name: 'Triumph',
          images: [{ url: 'https://readdy.ai/api/search-image?query=clean%20album%20design%2C%20white%20background%2C%20simple%20trophy%20outline%2C%20minimalist%20style%2C%20winning%20aesthetic&width=300&height=300&seq=energetic6&orientation=squarish', height: 300, width: 300 }]
        },
        external_urls: { spotify: 'https://spotify.com' },
        preview_url: ''
      },
      {
        id: 'demo47',
        name: 'Unstoppable Force',
        artists: [{ name: 'Power House' }],
        album: {
          name: 'Momentum',
          images: [{ url: 'https://readdy.ai/api/search-image?query=minimalist%20cover%20art%2C%20clean%20white%20background%2C%20simple%20geometric%20burst%2C%20contemporary%20typography%2C%20explosive&width=300&height=300&seq=energetic7&orientation=squarish', height: 300, width: 300 }]
        },
        external_urls: { spotify: 'https://spotify.com' },
        preview_url: ''
      },
      {
        id: 'demo48',
        name: 'Peak Performance',
        artists: [{ name: 'Elite Level' }],
        album: {
          name: 'Excellence',
          images: [{ url: 'https://readdy.ai/api/search-image?query=simple%20album%20cover%2C%20white%20background%2C%20minimalist%20mountain%20peak%2C%20clean%20design%2C%20achievement%20theme&width=300&height=300&seq=energetic8&orientation=squarish', height: 300, width: 300 }]
        },
        external_urls: { spotify: 'https://spotify.com' },
        preview_url: ''
      }
    ]
  };

  return demoTracks[mood] || [];
}
