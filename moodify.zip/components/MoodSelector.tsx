
'use client';

interface Mood {
  emoji: string;
  label: string;
  keyword: string;
  color: string;
}

const moods: Mood[] = [
  { emoji: '', label: 'Mutlu', keyword: 'happy', color: 'bg-gradient-to-br from-pink-300 to-pink-400 hover:from-pink-400 hover:to-pink-500' },
  { emoji: '', label: 'Üzgün', keyword: 'sad', color: 'bg-gradient-to-br from-gray-300 to-gray-400 hover:from-gray-400 hover:to-gray-500' },
  { emoji: '', label: 'Sinirli', keyword: 'angry', color: 'bg-gradient-to-br from-pink-400 to-rose-500 hover:from-pink-500 hover:to-rose-600' },
  { emoji: '', label: 'Yorgun', keyword: 'tired', color: 'bg-gradient-to-br from-slate-300 to-slate-400 hover:from-slate-400 hover:to-slate-500' },
  { emoji: '', label: 'Sakin', keyword: 'relaxed', color: 'bg-gradient-to-br from-pink-200 to-pink-300 hover:from-pink-300 hover:to-pink-400' },
  { emoji: '', label: 'Enerjik', keyword: 'energetic', color: 'bg-gradient-to-br from-rose-400 to-pink-500 hover:from-rose-500 hover:to-pink-600' },
];

interface MoodSelectorProps {
  onMoodSelect: (mood: Mood) => void;
  isLoading: boolean;
}

export default function MoodSelector({ onMoodSelect, isLoading }: MoodSelectorProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-pink-50 to-rose-50 px-6 py-8">
      <div className="max-w-md mx-auto">
        {/* Header Section */}
        <div className="text-center mb-16 pt-16">
          <div className="mb-8">
            <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-pink-400 to-rose-500 rounded-full shadow-xl mb-6 transform hover:scale-105 transition-all duration-300">
              <i className="ri-music-2-line text-3xl text-white"></i>
            </div>
          </div>
          <h1 className="text-3xl font-bold text-gray-800 mb-4 tracking-wide bg-gradient-to-r from-pink-500 to-rose-500 bg-clip-text text-transparent">
            Nasıl hissediyorsun?
          </h1>
          <p className="text-gray-600 text-lg font-medium leading-relaxed">
            Ruh halini seç ve kalbine dokunan müzikleri keşfet
          </p>
        </div>

        {/* Mood Grid */}
        <div className="grid grid-cols-2 gap-6 mb-12">
          {moods.map((mood, index) => (
            <button
              key={mood.keyword}
              onClick={() => onMoodSelect(mood)}
              disabled={isLoading}
              className={`
                ${mood.color}
                border-2 border-white/20 shadow-xl
                p-8 transform transition-all duration-300 ease-out
                hover:shadow-2xl hover:scale-[1.05] hover:-translate-y-2
                active:scale-[0.95] active:translate-y-0
                disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none
                flex flex-col items-center justify-center
                min-h-[130px] backdrop-blur-sm
                group relative overflow-hidden
              `}
              style={{
                borderRadius: index % 3 === 0 ? '2rem 0.5rem 2rem 0.5rem' : 
                            index % 3 === 1 ? '0.5rem 2rem 0.5rem 2rem' : 
                            '2rem 2rem 0.5rem 0.5rem',
                animationDelay: `${index * 150}ms`,
                animation: 'fadeInUp 0.8s ease-out forwards'
              }}
            >
              {/* Hexagon Shape */}
              <div className="relative">
                <div 
                  className="w-16 h-16 bg-white/30 backdrop-blur-sm flex items-center justify-center mb-4 group-hover:bg-white/40 transition-all duration-300 shadow-inner border border-white/20"
                  style={{
                    clipPath: 'polygon(30% 0%, 70% 0%, 100% 30%, 100% 70%, 70% 100%, 30% 100%, 0% 70%, 0% 30%)'
                  }}
                >
                  <div className="w-4 h-4 bg-white rounded-full opacity-80 shadow-md"></div>
                </div>
              </div>
              <span className="text-white font-bold text-lg tracking-wide drop-shadow-md">
                {mood.label}
              </span>
              {isLoading && (
                <div className="mt-3">
                  <div className="w-5 h-5 border-3 border-white border-t-transparent rounded-full animate-spin"></div>
                </div>
              )}
              
              {/* Background decoration */}
              <div className="absolute -top-2 -right-2 w-8 h-8 bg-white/10 rounded-full"></div>
              <div className="absolute -bottom-2 -left-2 w-6 h-6 bg-white/10 rounded-full"></div>
            </button>
          ))}
        </div>

        {/* Bottom Decoration */}
        <div className="text-center">
          <div className="inline-flex items-center gap-3 px-8 py-4 bg-gradient-to-r from-pink-300/20 to-gray-300/20 backdrop-blur-sm rounded-full shadow-lg border border-white/30">
            <div className="w-3 h-3 rounded-full bg-gradient-to-r from-pink-400 to-rose-400"></div>
            <div className="w-4 h-4 rounded-full bg-gradient-to-r from-gray-400 to-slate-400"></div>
            <div className="w-3 h-3 rounded-full bg-gradient-to-r from-rose-400 to-pink-500"></div>
          </div>
        </div>
      </div>
    </div>
  );
}
