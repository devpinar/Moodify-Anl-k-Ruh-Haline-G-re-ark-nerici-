
'use client';

import { SpotifyTrack } from '@/lib/spotify';

interface Mood {
  emoji: string;
  label: string;
  keyword: string;
  color: string;
}

interface MusicRecommendationsProps {
  mood: Mood;
  tracks: SpotifyTrack[];
  onBack: () => void;
  isLoading: boolean;
  error?: string;
}

const getMoodGradient = (moodKeyword: string) => {
  const gradients: Record<string, string> = {
    happy: 'from-pink-300 to-pink-400',
    sad: 'from-gray-300 to-gray-400',
    angry: 'from-pink-400 to-rose-500',
    tired: 'from-slate-300 to-slate-400',
    relaxed: 'from-pink-200 to-pink-300',
    energetic: 'from-rose-400 to-pink-500',
  };
  return gradients[moodKeyword] || 'from-pink-400 to-rose-500';
};

const getMoodLabels = (keyword: string) => {
  const labels: Record<string, string> = {
    happy: 'Mutlu',
    sad: 'Üzgün',
    angry: 'Sinirli',
    tired: 'Yorgun',
    relaxed: 'Sakin',
    energetic: 'Enerjik',
  };
  return labels[keyword] || keyword;
};

export default function MusicRecommendations({ 
  mood, 
  tracks, 
  onBack, 
  isLoading, 
  error 
}: MusicRecommendationsProps) {
  const openInSpotify = (spotifyUrl: string) => {
    window.open(spotifyUrl, '_blank');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-pink-50 to-rose-50">
      {/* Header */}
      <div className={`sticky top-0 z-20 bg-gradient-to-r ${getMoodGradient(mood.keyword)} backdrop-blur-sm border-b border-white/30 px-6 py-6 shadow-lg`}>
        <div className="max-w-md mx-auto">
          <div className="flex items-center gap-4">
            <button
              onClick={onBack}
              className="w-12 h-12 flex items-center justify-center bg-white/90 hover:bg-white shadow-xl rounded-2xl transition-all duration-200 hover:scale-110 hover:-translate-y-1"
            >
              <i className="ri-arrow-left-line text-xl text-gray-700"></i>
            </button>
            <div className="flex-1">
              <h1 className="text-2xl font-bold text-white tracking-wide drop-shadow-md">
                {getMoodLabels(mood.keyword)} Müzikler
              </h1>
              <p className="text-white/90 text-sm font-medium">
                Ruh haline özel seçilmiş şarkılar
              </p>
            </div>
            <div 
              className="w-12 h-12 bg-white/30 backdrop-blur-sm flex items-center justify-center shadow-inner border border-white/20"
              style={{
                clipPath: 'polygon(30% 0%, 70% 0%, 100% 30%, 100% 70%, 70% 100%, 30% 100%, 0% 70%, 0% 30%)'
              }}
            >
              <div className="w-4 h-4 rounded-full bg-white opacity-80"></div>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="px-6 py-8 pb-32">
        <div className="max-w-md mx-auto">
          {isLoading && (
            <div className="flex flex-col items-center justify-center py-20">
              <div className="w-20 h-20 border-4 border-pink-200 border-t-pink-500 rounded-full animate-spin mb-8 shadow-lg"></div>
              <p className="text-gray-700 font-bold text-lg">Sana özel şarkılar buluyorum...</p>
              <p className="text-gray-600 text-sm mt-2">Bu biraz zaman alabilir</p>
            </div>
          )}

          {error && (
            <div className="bg-gradient-to-r from-pink-300/20 to-gray-300/20 backdrop-blur-sm border-2 border-pink-300/30 rounded-3xl p-8 mb-8 shadow-xl">
              <div className="flex items-start gap-4">
                <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-pink-400 to-rose-500 flex items-center justify-center flex-shrink-0 shadow-lg">
                  <i className="ri-error-warning-line text-white text-xl"></i>
                </div>
                <div>
                  <p className="text-gray-800 font-bold text-lg mb-2">Müzik yüklenemedi</p>
                  <p className="text-gray-700 text-sm leading-relaxed font-medium">{error}</p>
                </div>
              </div>
            </div>
          )}

          {!isLoading && !error && tracks.length > 0 && (
            <div className="space-y-6">
              {tracks.map((track, index) => (
                <div
                  key={track.id}
                  className="bg-gradient-to-br from-white/90 to-white/70 backdrop-blur-md shadow-xl border-2 border-white/40 hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 overflow-hidden relative"
                  style={{
                    borderRadius: index % 3 === 0 ? '2rem 1rem 2rem 1rem' : 
                                index % 3 === 1 ? '1rem 2rem 1rem 2rem' : 
                                '2rem 2rem 1rem 1rem',
                    animationDelay: `${index * 100}ms`,
                    animation: 'fadeInUp 0.6s ease-out forwards'
                  }}
                >
                  <div className="p-6">
                    <div className="flex gap-5">
                      <div 
                        className="w-24 h-24 bg-gradient-to-br from-pink-400 to-rose-500 overflow-hidden flex-shrink-0 shadow-xl border-2 border-white/40"
                        style={{
                          borderRadius: '1.5rem 0.5rem 1.5rem 0.5rem'
                        }}
                      >
                        {track.album.images[0] ? (
                          <img
                            src={track.album.images[0].url}
                            alt={track.album.name}
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center">
                            <i className="ri-music-2-line text-white text-2xl"></i>
                          </div>
                        )}
                      </div>
                      
                      <div className="flex-1 min-w-0">
                        <h3 className="font-bold text-gray-800 text-lg truncate leading-tight">
                          {track.name}
                        </h3>
                        <p className="text-gray-600 text-sm truncate mt-1 font-semibold">
                          {track.artists.map(artist => artist.name).join(', ')}
                        </p>
                        <p className="text-gray-500 text-xs truncate mt-2 font-medium">
                          {track.album.name}
                        </p>
                      </div>
                    </div>

                    <button
                      onClick={() => openInSpotify(track.external_urls.spotify)}
                      className="w-full mt-6 bg-gradient-to-r from-pink-500 to-rose-500 hover:from-pink-600 hover:to-rose-600 text-white font-bold py-4 px-6 rounded-2xl flex items-center justify-center gap-3 transition-all duration-200 shadow-xl hover:shadow-2xl hover:-translate-y-1 border-2 border-pink-400/20"
                    >
                      <i className="ri-spotify-fill text-xl"></i>
                      <span className="font-bold tracking-wide">Spotify'da Çal</span>
                    </button>
                  </div>
                  
                  {/* Card decorations */}
                  <div className="absolute top-3 right-3 w-6 h-6 bg-gradient-to-br from-pink-400/30 to-rose-500/30 rounded-full"></div>
                  <div className="absolute bottom-3 left-3 w-4 h-4 bg-gradient-to-br from-gray-400/30 to-slate-500/30 rounded-full"></div>
                </div>
              ))}
            </div>
          )}

          {!isLoading && !error && tracks.length === 0 && (
            <div className="text-center py-20">
              <div className="w-28 h-28 bg-gradient-to-br from-pink-400 to-rose-500 rounded-full flex items-center justify-center mx-auto mb-8 shadow-2xl">
                <i className="ri-music-2-line text-5xl text-white"></i>
              </div>
              <p className="text-gray-800 text-xl font-bold mb-3">Şarkı bulunamadı</p>
              <p className="text-gray-600 text-sm font-medium leading-relaxed">
                Farklı bir ruh hali seçmeyi dene veya daha sonra tekrar kontrol et
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
